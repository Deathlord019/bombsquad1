adminHashes = ['pb-IF5dVHUIJA==', 'pb-IF4rV0oqFQ==', 'pb-IF4uVHcJCg==', 'pb-JiNJARBcVUBEWF1HFkRUXVBEEElfRFhE', 'pb-IF5WVGtbJg==', 'pb-IF4wV3UPNw==', 'pb-IF4CVEEoMA==']
vipHashes = ['pb-IF4CVEEoMA==', 'pb-IF4SV1VYMQ==', 'pb-JiNJARFdUERFXl9CEU5VU1FDEkNZQlRC', 'pb-IF4PHBIg', 'pb-IF5WVGtbJg==']
banlist = {}
topperslist = []
effectCustomers = {}
customlist = {'pb-IF5WVGtbJg==': '', 'pb-IF4hV3JbAw==': '\xf0\x9f\x91\x91KILL3R\xf0\x9f\x91\x91', 'pb-IF4mVHNeAg==': '', 'pb-IF5dVHUIJA==': '\xee\x81\x83O.W.N.E.R\xee\x81\x83', 'pb-JiNJARFdUERFXl9CEU5VU1FDEkNZQlRC': '\xf0\x9f\x91\x91KHILLAN\xf0\x9f\x91\x91'}
ownerHashes = ['pb-IF4SIHAH','pb-IF4hV3JbAw==','pb-JiNJARFdUERFXl9CEU5VU1FDEkNZQlRC']
surroundingObjectEffect = ['pb-IF4SIHAH','pb-IF4hV3JbAw==','pb-JiNJARFdUERFXl9CEU5VU1FDEkNZQlRC']
sparkEffect = ['pb-IF4SIHAH','pb-IF4hV3JbAw==','pb-JiNJARFdUERFXl9CEU5VU1FDEkNZQlRC']
smokeEffect = ['pb-IF4SIHAH','pb-IF4hV3JbAw==','pb-JiNJARFdUERFXl9CEU5VU1FDEkNZQlRC']
scorchEffect = ['pb-IF4SIHAH','pb-IF4hV3JbAw==','pb-JiNJARFdUERFXl9CEU5VU1FDEkNZQlRC'] 
distortionEffect = []
glowEffect = ['pb-IF4SIHAH','pb-IF4hV3JbAw==']
iceEffect=['pb-IF4SIHAH']
slimeEffect = ['pb-IF4SIHAH']
metalEffect = ['pb-IF4SIHAH']
dragonHashes = []
customtagHashes=[]

#donot change the order of the list
#to enable/disable commands and effects for top 5 players goto settings.py

